package view;

import controller.ControladorRequerimientosReto4;
import model.vo.LiderCiudad;
import model.vo.ProyectoCiudad;
import model.vo.SumaProveedor;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VistaRequerimientosReto4 extends JFrame{

    //Controlador
    public static ControladorRequerimientosReto4 controlador = new ControladorRequerimientosReto4();

    private static final long serialVersionUID = 1L;
    private JPanel contentPane; 
    private static JTextArea textArea;

    public VistaRequerimientosReto4(){

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(450, 200, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5,5,5,5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel etiquetaTitulo = new JLabel("RETO 5");
        etiquetaTitulo.setBounds(28, 6, 61, 16);
        contentPane.add(etiquetaTitulo);

        JLabel etiquetaNombre = new JLabel("Heiner Alexander Cufiño Martin");
        etiquetaNombre.setBounds(28, 34, 208, 16);
        contentPane.add(etiquetaNombre);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(28, 70, 737, 455);
        contentPane.add(scrollPane);

        textArea = new JTextArea();
        scrollPane.setViewportView(textArea);

        JButton btnConsulta1 = new JButton("Consulta Proyecto Ciudad");
        btnConsulta1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                requerimiento1();
            }
        });
        btnConsulta1.setBounds(28, 537, 117, 29);
        contentPane.add(btnConsulta1);

        JButton btnConsulta2 = new JButton("Consulta Suma Proveedor");
        btnConsulta2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                requerimiento3();
            }
        });
        btnConsulta2.setBounds(157, 537, 117, 29);
        contentPane.add(btnConsulta2);

        JButton btnConsulta3 = new JButton("Consulta Lider Ciudad");
        btnConsulta3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                requerimiento4();
            }
        });
        btnConsulta3.setBounds(286, 537, 117, 29);
        contentPane.add(btnConsulta3);

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                textArea.setText("");
            }
        });
        btnLimpiar.setBounds(648, 537, 117, 29);
        contentPane.add(btnLimpiar);

    }
    
    public static void requerimiento1() {

        try{
            ArrayList<ProyectoCiudad>proyectos = controlador.consultarProyectoCiudad();
            String salida = "*** Proyecto Ciudad *** \n\nConstructora\tFecha_Inicio\tClasificacion\n\n";

            for (ProyectoCiudad proyectoCiudad : proyectos) {
                salida += proyectoCiudad.getClasificacion();
                salida += "\t";
                salida += proyectoCiudad.getFechaInicio();
                salida += "\t";
                salida += proyectoCiudad.getClasificacion();
                salida += "\n";
            }
            textArea.setText(salida);

        }catch (SQLException e){
            System.err.println("Ha ocurrido un error" +e.getMessage());
        }
    }

    public static void requerimiento3() {
        
        try{
            ArrayList<SumaProveedor>sumProveedor = controlador.consultarSumaProveedor();
            String salida = "*** Suma Proveedor *** \n\nCantidades\n\n";

            for (SumaProveedor sumaProveedor : sumProveedor) {
                salida += sumaProveedor.getCantidad();
                salida += "\n";
            }
        }catch (SQLException e){
            System.err.println("Ha ocurrido un error" +e.getMessage());
        }
    }


    public static void requerimiento4() {

        try{
            ArrayList<LiderCiudad>liderCiudad = controlador.consultarLiderCiudad();
            String salida = "*** Lider Ciudad *** \n\nNombre Completo\n\n";

        for (LiderCiudad liderC : liderCiudad) {
            salida += liderC.getNombreLider();
            salida += "\n";
        }
        
        }catch (SQLException e){
            System.err.println("Ha ocurrido un error" +e.getMessage());
        }
    }

}


